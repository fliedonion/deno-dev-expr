# fetch() examples

The examples here demonstrate how to make fetch() requests.

- [`GET`](get.js) - makes a GET request to GitHub API endpoint.
- [`POST`](post.js) - makes a POST request to https://post.deno.dev (echoes the
  request body back).
